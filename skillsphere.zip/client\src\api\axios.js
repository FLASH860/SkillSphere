﻿import axios from 'axios';

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api' });

api.interceptors.request.use((config) => {
  const token = JSON.parse(localStorage.getItem('auth'))?.token;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default api;
